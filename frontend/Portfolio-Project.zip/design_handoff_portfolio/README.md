# Handoff: Bryan Sobalvarro — Portfolio Website

## Overview
A single-page portfolio website for Bryan Sobalvarro, a high school student targeting college admissions officers and engineering employers. The site showcases GitHub projects, CAD/3D models, skills, awards, and contact info. It is semi-professional in tone — warm, organized, and technically impressive without being corporate.

---

## About the Design Files
The file `Portfolio v2.html` in this folder is a **high-fidelity HTML design reference** — a fully working prototype showing the intended look, layout, and behavior. It is **not** production code to ship directly. Your task is to **recreate this design in your actual codebase or chosen framework** (React, Next.js, Vue, SvelteKit, etc.), using its established patterns, component libraries, and routing conventions.

**Fidelity: High-fidelity.** Colors, typography, spacing, animations, and interactions are final and should be matched pixel-accurately. All copy is also final except where marked as a placeholder.

---

## Tech Stack Used in Prototype (for reference)
- Vanilla HTML/CSS/JS — no framework
- Google Fonts: Space Grotesk + Inter
- Three.js r134 (CDN) for the 3D CAD viewer
- GitHub REST API (`/users/BeginnerProgrammer572/repos`) for live repo cards
- IntersectionObserver for scroll-triggered animations

---

## Screens / Views

This is a single-page site with 7 anchor sections. All sections share a fixed navigation bar.

---

### 1. Navigation Bar
**Purpose:** Global wayfinding; stays visible on scroll.

- **Height:** 62px, `position: fixed`, full width
- **Background:** `rgba(237,229,208,0.9)` with `backdrop-filter: blur(14px)`
- **Border-bottom:** 1px solid `#d4c4a4`
- **z-index:** 200
- **Left:** Logo "BS." — Space Grotesk 700, 1.05rem. The period is accent color `#c8670d`
- **Right:** Nav links as a flex row, gap 0.25rem
  - Link styles: 0.82rem Inter 500, color `#7a6a50`, padding `0.38rem 0.7rem`, border-radius 6px
  - Hover/active state: color `#c8670d`, background `#f2d8a0`
  - "Contact" is a CTA button: background `#c8670d`, white text, padding `0.42rem 1rem`
  - CTA hover: background `#a05210`
- **Active link detection:** Driven by scroll position — highlight the link matching the current section

---

### 2. Hero Section (`#hero`)
**Purpose:** First impression — name, tagline, CTAs, quick stats.

- **Layout:** `min-height: 100vh`, flex center, padding-top = nav height (62px)
- **Background decorations (purely CSS, no images):**
  - Radial gradient glow: `radial-gradient(ellipse 75% 65% at 72% 50%, rgba(223,123,24,0.07), transparent 68%)`
  - Dot grid: `background-image: radial-gradient(circle, rgba(26,25,22,0.07) 1px, transparent 1px)`, `background-size: 26px 26px`, masked on the right side using a radial mask
- **Content max-width:** 680px

**Elements (top to bottom):**
1. **Status pill:** inline-flex, rounded-full pill. Background `#f2d8a0`, border `rgba(223,123,24,0.22)`, color `#c8670d`. Contains a 6×6px orange dot + text "Open to opportunities". Font: 0.75rem Inter 600. Margin-bottom: 1.6rem
2. **Name H1:** "Bryan / Sobalvarro." — Space Grotesk 700, `clamp(3rem, 6.5vw, 5rem)`, letter-spacing -0.045em, line-height 1.0. Period is `#c8670d`. Margin-bottom: 1.2rem
3. **Tagline paragraph:** Color `#7a6a50`, 1.0rem, max-width 520px, line-height 1.7. Margin-bottom: 2.2rem
4. **Button row (flex, gap 0.85rem):**
   - Primary: background `#c8670d`, white text, padding `0.7rem 1.4rem`, border-radius 8px, 0.875rem Inter 500. GitHub SVG icon (15×15). Hover: darker bg + `translateY(-1px)` + amber shadow
   - Outline: background `#f8f2e2`, border `1px solid #d4c4a4`, dark text. Hover: accent border + accent color + lift
5. **Stats row** (below a top border `1px solid #d4c4a4`, margin-top 3.5rem, padding-top 2.5rem):
   - 3 stats side by side, gap 2.5rem
   - Number: Space Grotesk 700, 1.65rem, letter-spacing -0.04em
   - Label: 0.75rem, color `#b09878`
   - Values: "3+" / Years Coding, "2" / CAD Platforms, "1" / Club Founded

---

### 3. About Section (`#about`)
**Purpose:** Personal bio + highlight cards.

- **Background:** `#f8f2e2` (surface)
- **Layout:** CSS grid, 2 equal columns, gap 4rem
- **Scroll animation:** Fades up (`opacity: 0 → 1`, `translateY(22px → 0)`) on IntersectionObserver trigger

**Left column — Bio text:**
- Section label: 0.68rem Inter 600, letter-spacing 0.12em, uppercase, color `#c8670d`
- H2: Space Grotesk 700, `clamp(1.6rem, 3vw, 2rem)`, letter-spacing -0.03em
- 3 paragraphs: 0.9rem, color `#7a6a50`, margin-bottom 1rem each

**Right column — Highlight cards (4 cards, flex column, gap 0.85rem):**
Each card:
- Background `#ede5d0`, border `1px solid #d4c4a4`, border-radius 12px, padding `1rem 1.15rem`
- Flex row, gap 0.9rem, align-items flex-start
- **Icon container:** 34×34px, border-radius 8px, background `#f2d8a0`, color `#c8670d`. Contains a 17×17 inline SVG (stroke-based, stroke-width 2)
- **Title:** Space Grotesk 600, 0.85rem. **Description:** 0.77rem, color `#7a6a50`

Cards (title / description):
1. Robotics Club & Class Founder / "Built the program from the ground up — hardware, software, and full curriculum."
2. CAD Designer / "Proficient in Fusion 360 & AutoCAD for mechanical design and prototyping."
3. C++ Programmer / "Primary language for embedded systems, robotics firmware, and algorithms."
4. AI & Web Development / "Leveraging GitHub, Claude, and modern AI tools for rapid development."

---

### 4. Skills Section (`#skills`)
**Purpose:** Visual skill breakdown in 4 categories.

- **Background:** `#ede5d0` (bg)
- **Grid:** 2 columns × 2 rows, `repeat(2, 1fr)`, gap 1.25rem

**Each skill card:**
- Background `#f8f2e2`, border `1px solid #d4c4a4`, border-radius 12px, padding 1.5rem
- **Category name:** 0.68rem Inter 600, letter-spacing 0.1em, uppercase, color `#b09878`, margin-bottom 1.1rem
- **Skill rows:** flex, space-between, align-items center, margin-bottom 0.85rem
  - Name: 0.82rem Inter 500
  - Progress bar track: 72px wide × 3px tall, background `#d4c4a4`, border-radius 100px
  - Progress bar fill: background `#c8670d`, animated from 0% to target width on scroll-in (`transition: width 1s cubic-bezier(.4,0,.2,1) 0.2s`)

**4 Categories and skills:**

| Category | Skills (name / bar %) |
|---|---|
| Programming | C++ 82%, Python/Web 50%, GitHub 55%, JavaScript 55% |
| VEX Robotics | V5 85%, PROS *(C++ extension)* 76%, Autonomous Programming 78%, Driver Control 80% |
| CAD & Design | Fusion 360 78%, AutoCAD (.dwg) 72%, OnShape 68% |
| Engineering & AI | Robotics Systems 80%, AI / Claude Tools 62%, Embedded Systems 65% |

Note: "PROS" has an inline secondary label "(C++ extension)" in 0.72rem, color `#b09878`, font-weight 400.

---

### 5. GitHub Projects Section (`#github`)
**Purpose:** Live-fetched repository cards linking to GitHub.

- **Background:** `#f8f2e2` (surface)
- **API:** `GET https://api.github.com/users/BeginnerProgrammer572/repos?sort=updated&per_page=9`
- **Grid:** 3 columns, gap 1rem
- **Header row:** section label + H2 on left; "View all on GitHub →" link on right (0.82rem Inter 500, color `#c8670d`)

**Repo card:**
- Background `#ede5d0`, border `1px solid #d4c4a4`, border-radius 12px, padding 1.2rem
- Flex column, gap 0.45rem
- Hover: border-color `#c8670d`, `translateY(-2px)`, subtle shadow
- **Repo name:** Space Grotesk 600, 0.85rem, color `#c8670d`, truncated with ellipsis
- **Description:** 0.77rem, color `#7a6a50`, clamped to 2 lines
- **Meta row:** language dot (7×7px circle, language-specific color) + language name + star count
- Language colors: C++ `#f34b7d`, Python `#3572A5`, JavaScript `#f1e05a`, HTML `#e34c26`, CSS `#563d7c`, etc.

**Loading state:** Centered text "Loading repositories…" spanning full grid width
**Error state:** "Couldn't load live repos." + fallback GitHub link

---

### 6. CAD / 3D Models Section (`#cad`)
**Purpose:** Interactive 3D model viewer with Three.js + drop zone for real STL files.

- **Background:** `#ede5d0` (bg)
- **Layout:** CSS grid, `260px 1fr`, gap 1.5rem

**Left sidebar (260px):**
- 3 model selector buttons (flex column, gap 0.6rem)
- Each button: background `#f8f2e2`, border `1px solid #d4c4a4`, border-radius 12px, padding `0.9rem 1.05rem`, text-align left
- Active/hover: border `#c8670d`, background `#f2d8a0`
- Active name text: color `#c8670d`
- Button labels: name (Space Grotesk 600, 0.83rem) + description (0.72rem, color `#7a6a50`)
- Models: Arm Bracket, Drive Gear, Base Chassis
- **DWG note card** at bottom: background surface, border, padding `0.9rem 1rem`, 0.75rem text. Instructs user to export .DWG as .STL and drop onto viewer

**Right — 3D canvas (height 460px):**
- Background `#09090f` (near-black)
- Border-radius 12px, `overflow: hidden`
- `<canvas id="cad-canvas">` filling 100% width/height
- **Three.js scene setup:**
  - `ACESFilmicToneMapping`, exposure 1.05, shadow maps enabled
  - AmbientLight white 0.55 intensity
  - DirectionalLight white 0.9 at (5,9,4), casts shadows
  - DirectionalLight `#c8d8ff` 0.3 at (-4,2,-3) (fill)
  - PointLight `#df7b18` 0.65 at (-3,3,4) (accent glow)
  - GridHelper 7 units, 14 divisions, color `#1a1a2e`/`#14141f`, y = -1.2
- **Camera:** PerspectiveCamera FOV 42, starts at spherical coords (t:0.5, p:1.1, r:5.5)
- **Materials:** `MeshStandardMaterial` — silver-metal (color `#b4bdc4`, metalness 0.7, roughness 0.28), dark (color `#2a2a36`), amber (color `#df7b18`, emissive)
- **Edge highlights:** `EdgesGeometry` + `LineBasicMaterial` color `#df7b18` added as child of each mesh
- **Auto-spin:** rotates slowly (sph.t += 0.004/frame) until user interacts; double-click resets
- **Orbit controls (custom):** mousedown/mousemove for theta/phi drag, wheel for zoom (r: 2.8–14)
- **Touch support:** single-touch drag mapped to theta/phi
- **STL drop zone:** dragover shows overlay "Drop .STL file to load"; drop reads file as ArrayBuffer, parses binary STL (80-byte header, uint32 face count, 50 bytes/face), centers + scales geometry to fit ~3.2 units, replaces current model
- **Floating animation:** `model.position.y = Math.sin(tick * 0.7) * 0.05`

**Overlays on canvas:**
- Bottom center: hint pill "Drag to rotate · Scroll to zoom · Double-click to reset" (frosted glass style)
- Top right: "3D Interactive" badge (amber semi-transparent)

**3 demo models (procedurally generated):**
1. **Arm Bracket:** L-bracket shape — horizontal base plate + vertical wall + 2 ribs + 4 base holes (cylinders) + 4 wall holes
2. **Drive Gear:** Cylinder disk + center bore + 18 box teeth around perimeter + 5 spokes. Rotated 90° on X
3. **Base Chassis:** Flat plate + 2 side rails + 2 cross-members + 4 amber standoff cylinders with metal caps + 2 dark motor mount boxes

---

### 7. Awards & Achievements Section (`#awards`)
**Purpose:** Recognition cards.

- **Background:** `#f8f2e2` (surface)
- **Grid:** 2 columns, gap 1.15rem

**Each award card:**
- Background `#ede5d0`, border `1px solid #d4c4a4`, border-radius 12px, padding 1.35rem
- Flex row, gap 1rem
- **Icon:** 38×38px, border-radius 9px, background `#f2d8a0`, color `#c8670d`, inline SVG
- **Title:** Space Grotesk 600, 0.87rem
- **Description:** 0.78rem, color `#7a6a50`, line-height 1.55
- **Year/tag:** 0.72rem, color `#c8670d`, font-weight 600, margin-top 0.45rem

Cards:
1. Robotics Club & Class Founder — "Established the robotics program at my school…" — School Achievement
2. C++ Robotics Programming — "Developed firmware and control systems…" — Programming
3. CAD Engineering Design — "Designed functional mechanical parts…" — Engineering Design
4. AI-Powered Web Development — "Built this portfolio and other projects using AI tools…" — Innovation

---

### 8. Contact Section (`#contact`)
**Purpose:** Contact links + CTA panel.

- **Background:** `#ede5d0` (bg)
- **Layout:** 2-column grid, gap 4rem

**Left — contact links:**
- Intro paragraph: color `#7a6a50`, 0.9rem
- 2 contact link rows (flex, gap 0.85rem, background surface, border, border-radius 12px, padding `0.9rem 1.1rem`)
- Hover: border-color accent + `translateX(4px)`
- Icon box: 36×36px, background `#f2d8a0`, border-radius 8px, color `#c8670d`
- Label: 0.7rem `#b09878` | Value: 0.87rem Inter 500
- Email: bryans@gmail.com
- GitHub: BeginnerProgrammer572 → `https://github.com/BeginnerProgrammer572`

**Right — opportunity panel:**
- Background surface, border, border-radius 12px, padding 2rem
- H3: Space Grotesk 700, 1.1rem — "Open to opportunities"
- Description paragraph: 0.85rem, color `#7a6a50`
- Full-width primary CTA button: "Send a message →" → `mailto:bryans@gmail.com`

---

### 9. Footer
- Background `#261a08` (= `--text`)
- Color `rgba(255,255,255,0.35)`, text-align center, padding 1.75rem, 0.78rem
- Text: "Bryan Sobalvarro · Built with **precision** · 2026"
- "precision" in color `#e8902a` (accent-2), font-weight 500

---

## Design Tokens

```
/* Colors */
--bg:         #ede5d0   /* Page background — warm tan */
--surface:    #f8f2e2   /* Card/section background */
--text:       #261a08   /* Primary text */
--text-2:     #7a6a50   /* Secondary text */
--text-3:     #b09878   /* Tertiary / muted */
--accent:     #c8670d   /* Primary amber/orange */
--accent-2:   #e8902a   /* Lighter amber (footer) */
--accent-bg:  #f2d8a0   /* Accent tint for icon backgrounds, pill, active states */
--accent-dk:  #a05210   /* Darker accent for hover */
--border:     #d4c4a4   /* All borders */

/* Typography */
Heading font: Space Grotesk (400, 500, 600, 700) — Google Fonts
Body font:    Inter (300, 400, 500) — Google Fonts

/* Spacing */
--radius:     12px      /* All card/button border radii */
--nav-h:      62px
--max-w:      1080px    /* Content max-width */
Section padding: 5.5rem top/bottom
Container padding: 0 2rem (sides)

/* Shadows */
Hover card: 0 6px 20px rgba(0,0,0,0.07)
Button hover: 0 4px 18px rgba(223,123,24,0.28)

/* Transitions */
Standard: 0.18s ease
Skill bars: width 1s cubic-bezier(.4,0,.2,1) 0.2s delay
Fade-up: opacity + translateY 0.6s ease
```

---

## Interactions & Behavior

| Interaction | Behavior |
|---|---|
| Scroll | Sections fade up (`opacity 0→1`, `translateY 22px→0`) via IntersectionObserver at 10% visibility |
| Scroll | Skill bar fills animate to target width on section entering viewport |
| Scroll | Nav link matching current section gets active highlight |
| Nav links | Smooth scroll to anchor |
| Repo cards | Open GitHub repo in new tab |
| Contact links | Email opens mailto; GitHub opens profile in new tab |
| Model buttons | Switch Three.js scene to corresponding 3D model, reset camera |
| 3D canvas drag | Orbit camera (theta/phi spherical) |
| 3D canvas scroll | Zoom (radius 2.8–14) |
| 3D canvas double-click | Reset camera + resume auto-spin |
| 3D canvas drag (touch) | Single-finger orbit |
| 3D canvas drop | Load binary STL file, center + scale, replace current model |
| 3D auto-spin | Slow Y rotation (theta += 0.004/frame), pauses on mouse interaction |

---

## Responsive Breakpoints

| Breakpoint | Changes |
|---|---|
| ≤ 820px | About, Contact grids → 1 column; Skills grid → 1 column; CAD sidebar → flex row wrap; Awards → 1 column; Most nav links hidden (keep last 2) |
| ≤ 520px | Repos → 1 column; Hero stats gap reduced; Nav/wrap padding reduced |

---

## Assets
- All icons are inline SVGs (stroke-based, 17–18px, stroke-width 2, rounded linecap/join). No external icon library needed.
- No images used anywhere in the design. All visual elements are CSS or Three.js.
- Three.js loaded from CDN: `https://cdnjs.cloudflare.com/ajax/libs/three.js/r134/three.min.js`

---

## Files in This Package

| File | Purpose |
|---|---|
| `README.md` | This document — full implementation spec |
| `Portfolio v2.html` | Complete hi-fi HTML prototype — reference implementation |
